const Copyright = () => {
  return (
    <copyright>
        <div className="col-full foot-center">
          <p>&copy; 2024 - Capstone Meta Front-End Developer by Szymon Gryzło</p>
        </div>
    </copyright>
  );
};

export default Copyright;
